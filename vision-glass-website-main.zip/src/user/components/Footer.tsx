import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { Phone, Mail, MapPin, ArrowUpRight, CheckCircle, MessageCircle, Instagram, Facebook } from "lucide-react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import logo from "@/images/logo_img/logo.png";

gsap.registerPlugin(ScrollTrigger);

const marqueeWords = [
  "Glass Partitions", "Structural Facade", "Aluminium Windows",
  "LED Mirrors", "UPVC Windows", "Glass Glazing",
  "Interior Solutions", "Curtain Wall", "PVC Doors",
  "Decorative Glass", "Acid Etching", "Bend Glass",
];

const navLinks = [
  { label: "Home", to: "/" },
  { label: "Services", to: "/services" },
  { label: "Gallery", to: "/gallery" },
  { label: "About", to: "/about" },
  { label: "Contact", to: "/contact" },
];

const services = [
  "Glass Partitions",
  "Aluminium & UPVC Windows",
  "Structural Facade",
  "Glass Glazing",
  "Interior Solutions",
  "Decorative Mirrors",
  "LED Mirror Work",
  "PVC Fiber Doors",
];

const Footer = () => {
  const footerRef = useRef<HTMLElement>(null);
  const dividerRef = useRef<HTMLDivElement>(null);
  const bottomRef  = useRef<HTMLDivElement>(null);
  const [windowWidth, setWindowWidth] = useState(typeof window !== "undefined" ? window.innerWidth : 1200);

  useEffect(() => {
    const handleResize = () => setWindowWidth(window.innerWidth);
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(".ft-col", {
        scrollTrigger: { trigger: footerRef.current, start: "top 90%" },
        y: 48, opacity: 0, duration: 0.85, stagger: 0.12, ease: "power3.out",
      });
      gsap.from(".ft-logo", {
        scrollTrigger: { trigger: footerRef.current, start: "top 90%" },
        x: -30, opacity: 0, duration: 1, ease: "power3.out",
      });
    }, footerRef);
    return () => ctx.revert();
  }, []);

  useEffect(() => {
    const els = [dividerRef.current, bottomRef.current].filter(Boolean) as HTMLElement[];
    const show = () => els.forEach((el) => el.classList.add("ft-visible"));
    const fallback = setTimeout(show, 1500);
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("ft-visible");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0, rootMargin: "0px" }
    );
    els.forEach((el) => observer.observe(el));
    return () => { clearTimeout(fallback); observer.disconnect(); };
  }, []);

  return (
    <footer ref={footerRef} className="bg-[#020617] text-white">

      {/* ══ MARQUEE STRIP ══ */}
      <div className="overflow-hidden bg-[#0ea5e9]">
        <div
          className="flex py-2.5"
          style={{ width: "max-content", animation: "ftMarquee 40s linear infinite" }}
          onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.animationPlayState = "paused"; }}
          onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.animationPlayState = "running"; }}
        >
          <div className="flex items-center gap-10 text-[13px] font-black text-white tracking-[0.2em] whitespace-nowrap uppercase">
            {[...marqueeWords, ...marqueeWords].map((word, i) => (
              <span key={i} className="flex items-center gap-3">
                <CheckCircle className="w-4 h-4 text-white" />
                {word}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* ══ MAIN GRID ══ */}
      <div className="w-full px-5 md:px-12 lg:px-20 pt-16 pb-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-12 gap-10 md:gap-6">

          {/* Col 1: Brand */}
          <div className="ft-col sm:col-span-2 md:col-span-1 lg:col-span-3 flex flex-col items-center md:items-start text-center md:text-left">
            <Link to="/" className="ft-logo flex flex-col items-center md:items-start gap-3 mb-8 group">
              <img
                src={logo}
                alt="Vision Glass Creation"
                className="h-12 sm:h-16 w-auto object-contain transition-transform duration-500 group-hover:scale-110 brightness-0 invert"
              />
              <div className="flex flex-col items-center md:items-start">
                <span className="text-xl sm:text-3xl font-black text-white leading-none tracking-tighter">VISION GLASS</span>
                <span className="text-[12px] sm:text-[16px] font-bold text-[#0ea5e9] tracking-[0.4em] mt-1.5 uppercase">CREATION</span>
              </div>
            </Link>
            <p className="text-white/90 text-base sm:text-lg leading-relaxed max-w-sm mb-10 font-bold">
              Pune's leading expert in premium window and glass solutions for over 15 years.
            </p>

            {/* Social Connect Group */}
            <div className="flex items-center gap-4">
               <a 
                 href="https://wa.me/919921917083" 
                 target="_blank" 
                 rel="noreferrer" 
                 className="w-12 h-12 rounded-xl bg-emerald-500 flex items-center justify-center text-white border border-emerald-400 hover:bg-emerald-600 transition-all shadow-lg shadow-emerald-500/20 group"
                 title="WhatsApp"
               >
                  <MessageCircle className="w-6 h-6 group-hover:rotate-12 transition-transform" />
               </a>
               <a 
                 href="https://instagram.com/vision_glass" 
                 target="_blank" 
                 rel="noreferrer" 
                 className="w-12 h-12 rounded-xl bg-pink-500 flex items-center justify-center text-white border border-pink-400 hover:bg-pink-600 transition-all shadow-lg shadow-pink-500/20 group"
                 title="Instagram"
               >
                  <Instagram className="w-6 h-6 group-hover:scale-110 transition-transform" />
               </a>
               <a 
                 href="https://facebook.com/vision_glass" 
                 target="_blank" 
                 rel="noreferrer" 
                 className="w-12 h-12 rounded-xl bg-blue-600 flex items-center justify-center text-white border border-blue-500 hover:bg-blue-700 transition-all shadow-lg shadow-blue-500/20 group"
                 title="Facebook"
               >
                  <Facebook className="w-6 h-6 group-hover:-rotate-12 transition-transform" />
               </a>
            </div>
          </div>

          {/* Col 2: Scanner (Hidden on mobile) */}
          <div className="ft-col hidden md:flex lg:col-span-2 flex-col items-start">
            <h4 className="text-[18px] font-black text-white uppercase tracking-[0.25em] mb-6 border-b border-[#0ea5e9]/30 pb-2 inline-block">
              Scan to Visit
            </h4>
            <div className="inline-flex flex-col items-center rounded-xl p-3 gap-2 bg-white/5 border border-white/10">
              <img
                src="/scanner_img/scanner.jpg"
                alt="Scan to visit"
                className="w-[100px] h-[100px] rounded-lg block object-cover"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src =
                    "https://api.qrserver.com/v1/create-qr-code/?size=100x100&color=e0f2fe&bgcolor=020617&data=https://maps.google.com/?q=Plot+595+Ganganagar+Nigdi+Pimpri-Chinchwad";
                }}
              />
              <p className="text-[13px] leading-tight text-center font-light text-gray-300">
                Opens Google Maps
              </p>
            </div>
          </div>

          {/* Col 3: Navigate */}
          <div className="ft-col lg:col-span-2">
            <h4 className="text-[18px] font-black text-white uppercase tracking-[0.25em] mb-6 border-b border-[#0ea5e9]/30 pb-2 inline-block">
              Navigate
            </h4>
            <div className="flex flex-col gap-3">
              {navLinks.map((link) => (
                <Link
                  key={link.label}
                  to={link.to}
                  className="text-white/90 text-base sm:text-[18px] hover:text-[#0ea5e9] transition-all duration-300 flex items-center gap-2 font-bold group"
                >
                  <CheckCircle className="w-3.5 h-3.5 text-sky-500 opacity-60 group-hover:opacity-100" />
                  {link.label}
                  <ArrowUpRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                </Link>
              ))}
            </div>
          </div>

          {/* Col 4: Services */}
          <div className="ft-col lg:col-span-2">
            <h4 className="text-[18px] font-black text-white uppercase tracking-[0.25em] mb-6 border-b border-[#0ea5e9]/30 pb-2 inline-block">
              Services
            </h4>
            <div className="flex flex-col gap-3">
              {services.map((s) => (
                <Link
                  key={s}
                  to="/services"
                  className="text-white/90 text-[13px] sm:text-[15px] hover:text-[#0ea5e9] transition-colors font-bold flex items-center gap-2 group"
                >
                  <CheckCircle className="w-3 h-3 text-sky-500 opacity-60 group-hover:opacity-100" />
                  {s}
                </Link>
              ))}
            </div>
          </div>

          {/* Col 5: Contact */}
          <div className="ft-col sm:col-span-2 md:col-span-1 lg:col-span-3">
            <h4 className="text-[18px] font-black text-white uppercase tracking-[0.25em] mb-6 border-b border-[#0ea5e9]/30 pb-2 inline-block">
              Contact
            </h4>
            <div className="flex flex-col gap-5">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-white/5 flex items-center justify-center shrink-0">
                  <Phone className="w-5 h-5 sm:w-6 sm:h-6 text-[#0ea5e9]" />
                </div>
                <div className="flex flex-col gap-1">
                  <a href="tel:+919921917083" className="text-white font-black text-base sm:text-lg hover:text-[#0ea5e9] transition-colors">+91 99219 17083</a>
                  <a href="tel:+917840917083" className="text-white font-black text-base sm:text-lg hover:text-[#0ea5e9] transition-colors">+91 78409 17083</a>
                </div>
              </div>
              <a href="mailto:visionglasscreation1@gmail.com" className="flex items-center gap-4 group">
                <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-white/5 flex items-center justify-center shrink-0">
                  <Mail className="w-5 h-5 sm:w-6 sm:h-6 text-[#0ea5e9]" />
                </div>
                <span className="text-white/95 text-xs sm:text-base font-black break-all">visionglasscreation1@gmail.com</span>
              </a>
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center shrink-0">
                  <MapPin className="w-5 h-5 text-[#0ea5e9]" />
                </div>
                <span className="text-white/90 text-sm sm:text-base font-bold leading-relaxed">
                  Plot No. 595, Ganganagar, <br className="hidden sm:block" />Pimpri-Chinchwad, MH 411444
                </span>
              </div>
            </div>
          </div>

          {/* Mobile Scanner */}
          <div className="ft-col flex flex-col items-center md:hidden mt-8">
            <h4 className="text-[16px] font-black text-white uppercase tracking-[0.2em] mb-4 border-b border-[#0ea5e9]/30 pb-2">
              Scan to Visit
            </h4>
            <div className="bg-white/5 border border-white/10 rounded-xl p-3">
              <img
                src="/scanner_img/scanner.jpg"
                alt="Scan to visit"
                className="w-[80px] h-[80px] rounded-lg object-cover"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src =
                    "https://api.qrserver.com/v1/create-qr-code/?size=80x80&color=e0f2fe&bgcolor=020617&data=https://maps.google.com/?q=Plot+595+Ganganagar+Nigdi+Pimpri-Chinchwad";
                }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Divider */}
      <div
        ref={dividerRef}
        className="ft-divider mx-4 md:mx-8 h-px bg-white/20 scale-x-0 origin-left transition-transform duration-[1.4s] ease-[cubic-bezier(0.16,1,0.3,1)]"
      />

      {/* Bottom Bar */}
      <div
        ref={bottomRef}
        className="ft-bottom w-full px-6 md:px-12 lg:px-20 py-8 flex flex-col md:flex-row items-center justify-between gap-6 opacity-0 translate-y-3 transition-all duration-[0.8s] delay-200"
      >
        <p className="text-white/70 text-sm sm:text-base font-bold text-center md:text-left">
          Empowering architectural brilliance through premium glass solutions.
        </p>
        <div className="flex flex-col sm:flex-row items-center gap-2 sm:gap-6 text-sm text-white/60 font-bold">
          <span>© {new Date().getFullYear()} Vision Glass Creation.</span>
          <span className="hidden sm:inline w-1 h-1 rounded-full bg-white/20" />
          <span>All rights reserved.</span>
        </div>
      </div>

      <style>{`
        @keyframes ftMarquee {
          from { transform: translateX(0); }
          to   { transform: translateX(-50%); }
        }
        .ft-divider.ft-visible { transform: scaleX(1); }
        .ft-bottom.ft-visible { opacity: 1; transform: translateY(0); }
      `}</style>
    </footer>
  );
};

export default Footer;
