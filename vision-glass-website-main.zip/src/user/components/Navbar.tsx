import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, Phone } from "lucide-react";
import { Button } from "@/shared/components/ui/button";
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from "@/shared/components/ui/sheet";
import logo from "@/images/logo_img/logo.png";

const navLinks = [
  { label: "Home", to: "/" },
  { label: "About", to: "/about" },
  { label: "Services", to: "/services" },
  { label: "Gallery", to: "/gallery" },
  { label: "Contact", to: "/contact" },
];

const Navbar = () => {
  const [scrollY, setScrollY] = useState(0);
  const [windowWidth, setWindowWidth] = useState(typeof window !== "undefined" ? window.innerWidth : 1200);
  const [open, setOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    let rafId = 0;
    const onScroll = () => {
      cancelAnimationFrame(rafId);
      rafId = requestAnimationFrame(() => setScrollY(window.scrollY));
    };
    const onResize = () => {
      setWindowWidth(window.innerWidth);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onResize);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onResize);
      cancelAnimationFrame(rafId);
    };
  }, []);

  const progress = Math.min(scrollY / 80, 1);
  const isHome = location.pathname === "/";

  const bgOpacity = isHome ? progress * 0.97 : 0.97;
  const blurAmount = isHome ? progress * 20 : 20;
  const shadowOpacity = isHome ? progress * 0.08 : 0.08;
  const borderOpacity = isHome ? progress * 0.08 : 0.08;
  
  // Adjusted heights for mobile vs desktop
  const isMobile = windowWidth < 768;
  const baseHeight = isMobile ? 64 : 96;
  const scrollReduction = isMobile ? 4 : 16;
  const navHeight = baseHeight - progress * scrollReduction;
  
  const logoHeightBase = isMobile ? 36 : 48;
  const logoReduction = isMobile ? 4 : 6;
  const currentLogoHeight = logoHeightBase - progress * logoReduction;

  const isTransparent = isHome && progress < 0.5;
  const hoverBg = isTransparent ? "rgba(255,255,255,0.1)" : "rgba(0,0,0,0.04)";

  const getLinkColor = (isActive: boolean) => {
    if (isActive) return isTransparent ? "#ffffff" : "var(--primary)";
    return isTransparent ? "rgba(255,255,255,0.85)" : "var(--foreground)";
  };

  return (
    <>
      <style>{`
        .nav-link-hover:hover { background: ${hoverBg}; border-radius: 8px; }
        .nav-link-hover { transition: color 0.5s ease, background 0.2s ease; }
      `}</style>

      <nav
        className="fixed top-0 left-0 right-0 z-50"
        style={{
          height: `${navHeight}px`,
          background: `rgba(255,255,255,${bgOpacity})`,
          backdropFilter: `blur(${blurAmount}px)`,
          WebkitBackdropFilter: `blur(${blurAmount}px)`,
          boxShadow: `0 1px 24px rgba(0,0,0,${shadowOpacity})`,
          borderBottom: `1px solid rgba(0,0,0,${borderOpacity})`,
          transition: "height 0.2s ease",
        }}
      >
        <div className="w-full flex items-center justify-between h-full px-6 md:px-12">

          {/* ── Logo ── */}
          <Link to="/" className="flex items-center gap-4 group shrink-0">
            <img
              src={logo}
              alt="Vision Glass Creation"
              className="object-contain flex-shrink-0"
              style={{
                height: `${currentLogoHeight}px`,
                width: "auto",
                transition: "height 0.2s ease",
                filter: isTransparent ? "brightness(0) invert(1)" : "none",
              }}
            />
            <div>
              {/* "Vision Glass" — bold, normal case */}
              <span
                className="font-black text-sm sm:text-lg leading-tight block"
                style={{
                  color: isTransparent ? "rgba(255,255,255,1)" : "var(--foreground)",
                  transition: "color 0.5s ease",
                  letterSpacing: "-0.01em",
                }}
              >
                Vision Glass
              </span>
              <span
                className="block font-semibold"
                style={{
                  fontSize: isMobile ? "9px" : "11px",
                  letterSpacing: "0.25em",
                  textTransform: "uppercase",
                  color: isTransparent ? "#ffffff" : "rgba(0,0,0,0.9)",
                  transition: "color 0.5s ease",
                  marginTop: "1px",
                }}
              >
                Creation
              </span>
            </div>
          </Link>

          {/* ── Desktop Nav ── */}
          <div className="hidden md:flex items-center gap-0.5">
            {navLinks.map((link) => {
              const isActive = location.pathname === link.to;
              return (
                <Link
                  key={link.to}
                  to={link.to}
                  className="nav-link-hover relative px-6 py-2 text-xl font-bold"
                  style={{ color: getLinkColor(isActive) }}
                >
                  {link.label}
                  <span
                    style={{
                      position: "absolute",
                      bottom: 0,
                      left: "8px",
                      right: "8px",
                      height: "2.5px",
                      borderRadius: "999px",
                      background: "#0ea5e9",
                      opacity: isActive ? 1 : 0,
                      transform: isActive ? "scaleX(1)" : "scaleX(0.4)",
                      transformOrigin: "center",
                      transition: "opacity 0.3s ease, transform 0.3s cubic-bezier(0.16,1,0.3,1)",
                    }}
                  />
                </Link>
              );
            })}
          </div>

          {/* ── Right: phone → Get Quote → Location → hamburger ── */}
          <div className="flex items-center gap-2 md:gap-3">

            {/* Phone — large screens only */}
            <a
              href="tel:+919921917083"
              className="hidden lg:flex items-center gap-2 text-xl font-bold"
              style={{
                color: isTransparent ? "rgba(255,255,255,0.7)" : "var(--muted-foreground)",
                transition: "color 0.5s ease",
              }}
            >
              <Phone className="w-4 h-4" />
              +91 99219 17083
            </a>

            {/* Contact Us */}
            <Link to="/contact" className="hidden md:block">
              <Button size="sm" className="rounded-full px-6 shadow-md shadow-primary/20 hover:shadow-lg hover:shadow-primary/30 transition-all duration-300">
                Contact Us
              </Button>
            </Link>



            {/* Mobile hamburger */}
            <Sheet open={open} onOpenChange={setOpen}>
              <SheetTrigger asChild className="md:hidden">
                <button
                  className="p-2 rounded-lg"
                  style={{
                    color: isTransparent ? "rgba(255,255,255,1)" : "var(--foreground)",
                    transition: "color 0.5s ease",
                  }}
                >
                  <Menu className="w-5 h-5" />
                </button>
              </SheetTrigger>
              <SheetContent side="right" className="w-72">
                <SheetTitle className="flex items-center gap-2.5 mb-8">
                  <img src={logo} alt="Vision Glass Creation" className="h-12 w-auto object-contain flex-shrink-0" />
                  <div>
                    <p className="font-extrabold text-base leading-tight" style={{ letterSpacing: "-0.01em" }}>Vision Glass</p>
                    <p className="font-semibold" style={{ fontSize: "11px", letterSpacing: "0.25em", textTransform: "uppercase", color: "rgba(0,0,0,0.95)", marginTop: "1px" }}>
                      Creation
                    </p>
                  </div>
                </SheetTitle>
                <div className="flex flex-col gap-1">
                  {navLinks.map((link) => (
                    <Link
                      key={link.to}
                      to={link.to}
                      onClick={() => setOpen(false)}
                      className={`px-4 py-3 rounded-xl text-xl font-bold transition-colors ${location.pathname === link.to
                          ? "text-primary bg-primary/10"
                          : "text-foreground hover:bg-muted"
                        }`}
                    >
                      {link.label}
                    </Link>
                  ))}
                  <div className="pt-4 mt-2 border-t border-border space-y-3">
                    <a
                      href="tel:+919921917083"
                      className="flex items-center gap-2 px-4 py-3 rounded-xl text-xl font-bold text-muted-foreground hover:bg-muted transition-colors"
                    >
                      <Phone className="w-4 h-4" /> +91 99219 17083
                    </a>
                    <Link to="/contact" onClick={() => setOpen(false)}>
                      <Button className="w-full rounded-full">Contact Us</Button>
                    </Link>
                  </div>
                </div>
              </SheetContent>
            </Sheet>

          </div>
        </div>
      </nav>
    </>
  );
};

export default Navbar;
