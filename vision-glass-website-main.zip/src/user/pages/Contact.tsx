import { useState, useEffect } from "react";
import PageHero from "@/user/components/PageHero";
import { Button } from "@/shared/components/ui/button";
import { Input } from "@/shared/components/ui/input";
import { Textarea } from "@/shared/components/ui/textarea";
import { 
  Phone, 
  Mail, 
  MapPin, 
  Send, 
  MessageCircle, 
  Instagram, 
  CheckCircle2,
  Loader2,
  Clock,
  ShieldCheck
} from "lucide-react";
import { getSiteMetadata, addDocument } from "@/shared/lib/firestore-service";
import { toast } from "sonner";

const BLUE = "#0ea5e9";

const Contact = () => {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    service: "",
    message: ""
  });

  useEffect(() => {
    const fetchContact = async () => {
      try {
        const result = await getSiteMetadata("contact");
        if (result) {
            setData(result);
        } else {
            // Fallback for missing record
            setData({
                phone: "+91 99219 17083",
                officePhone: "+91 78409 17083",
                email: "visionglasscreation1@gmail.com",
                address: "Plot No. 595, Ganganagar, Nigdi, Pimpri-Chinchwad 411044",
                socials: { whatsapp: "919921917083", instagram: "@vision_glass" },
                mapEmbedUrl: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3781.2!2d73.77!3d18.65!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMTjCsDM5JzAwLjAiTiA3M8KwNDYnMTIuMCJF!5e0!3m2!1sen!2sin!4v1700000000000"
            });
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchContact();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.phone) {
        toast.error("Please provide your name and contact number");
        return;
    }

    setSubmitting(true);
    try {
        await addDocument("inquiries", {
            ...formData,
            createdAt: new Date().toISOString()
        });
        toast.success("Inquiry sent successfully! We will contact you shortly.");
        setFormData({ name: "", phone: "", email: "", service: "", message: "" });
    } catch (err) {
        toast.error("Failed to send inquiry. Please try again.");
    } finally {
        setSubmitting(false);
    }
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
    </div>
  );

  return (
    <div className="animate-in fade-in duration-700 bg-background pb-32">
      <PageHero
        title="Contact Us"
        subtitle="Get in touch for expert glass and window solutions"
        breadcrumb={[{ label: "Home", to: "/" }, { label: "Contact" }]}
      />

      <section className="py-16 md:py-32">
        <div className="w-full px-5 md:px-20 lg:px-32">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24">
            
            {/* Left: Combined Single Card */}
            <div className="p-8 md:p-12 h-full rounded-[2rem] md:rounded-[2.5rem] bg-white border border-border shadow-2xl space-y-12 relative overflow-hidden flex flex-col justify-between">
              <div className="absolute top-0 right-0 w-40 h-40 bg-sky-50 rounded-bl-full opacity-50" />
              
              <div className="space-y-12">
                {/* Intro Part */}
                <div className="relative z-10">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-[2px] rounded-full bg-primary" />
                    <p className="text-primary text-xs font-semibold uppercase tracking-widest">Connect With Us</p>
                  </div>
                  <h2 className="text-4xl font-extrabold tracking-tight text-black mb-6">Let's Build Something Together</h2>
                  <p className="text-muted-foreground text-lg leading-relaxed">
                    Reach out to Vision Glass Creation for professional glass installations, structural glazing, and custom architectural glass work in Pune.
                  </p>
                </div>

                <div className="space-y-10 relative z-10 pt-10 border-t border-slate-50">
                  {/* Call Section */}
                  <div className="flex items-start gap-6">
                      <div className="w-14 h-14 rounded-2xl bg-sky-500 flex items-center justify-center text-white shrink-0 shadow-lg shadow-sky-100">
                        <Phone className="w-6 h-6" />
                      </div>
                      <div>
                          <p className="text-[11px] font-black uppercase text-sky-600 tracking-[0.2em] mb-2 leading-none">Call Us</p>
                          <div className="space-y-1">
                            <p className="text-2xl font-black text-black tracking-tight">{data.phone}</p>
                            <p className="text-lg font-bold text-muted-foreground">{data.officePhone}</p>
                          </div>
                      </div>
                  </div>

                  {/* Email Section */}
                  <div className="flex items-start gap-6 pt-2">
                      <div className="w-14 h-14 rounded-2xl bg-slate-900 flex items-center justify-center text-white shrink-0 shadow-lg shadow-slate-100">
                        <Mail className="w-6 h-6" />
                      </div>
                      <div>
                          <p className="text-[11px] font-black uppercase text-slate-400 tracking-[0.2em] mb-2 leading-none">Email Us</p>
                          <p className="text-xl font-black text-black break-all tracking-tight">{data.email}</p>
                      </div>
                  </div>

                  {/* Address Section */}
                  <div className="flex items-start gap-6 pt-2">
                      <div className="w-14 h-14 rounded-2xl bg-emerald-500 flex items-center justify-center text-white shrink-0 shadow-lg shadow-emerald-100">
                        <MapPin className="w-6 h-6" />
                      </div>
                      <div>
                          <p className="text-[11px] font-black uppercase text-emerald-600 tracking-[0.2em] mb-2 leading-none">Visit Factory / Office</p>
                          <p className="text-lg font-bold text-black leading-relaxed">{data.address}</p>
                      </div>
                  </div>
                </div>
              </div>

            </div>

            {/* Right: Form */}
            <div className="bg-white h-full rounded-[2rem] md:rounded-3xl p-6 md:p-12 shadow-2xl border border-border relative overflow-hidden flex flex-col">
                <div className="absolute top-0 left-0 w-full h-1" style={{ backgroundColor: BLUE }} />
                
                <h3 className="text-2xl font-bold text-black mb-8 uppercase tracking-tight">Send a Quotation Request</h3>
                
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                            <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest pl-1">Full Name</label>
                            <Input 
                                placeholder="John Doe" 
                                value={formData.name}
                                onChange={(e) => setFormData({...formData, name: e.target.value})}
                                className="h-14 rounded-xl border-2 border-slate-50 focus:border-sky-500 font-bold"
                            />
                        </div>
                        <div className="space-y-2">
                            <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest pl-1">Contact Number</label>
                            <Input 
                                placeholder="+91 xxxxx xxxxx" 
                                value={formData.phone}
                                onChange={(e) => setFormData({...formData, phone: e.target.value})}
                                className="h-14 rounded-xl border-2 border-slate-50 focus:border-sky-500 font-bold"
                            />
                        </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                            <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest pl-1">Email (Optional)</label>
                            <Input 
                                placeholder="john@example.com" 
                                value={formData.email}
                                onChange={(e) => setFormData({...formData, email: e.target.value})}
                                className="h-14 rounded-xl border-2 border-slate-50 focus:border-sky-500 font-bold"
                            />
                        </div>
                        <div className="space-y-2">
                            <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest pl-1">Requirement</label>
                            <select 
                                value={formData.service}
                                onChange={(e) => setFormData({...formData, service: e.target.value})}
                                className="w-full h-14 rounded-xl border-2 border-slate-50 bg-white focus:border-sky-500 font-bold px-4 text-sm"
                            >
                                <option value="">Select Service Type</option>
                                <option value="Glass Partitions">Glass Partitions</option>
                                <option value="Windows Systems">Windows Systems</option>
                                <option value="Structural Facade">Structural Facade</option>
                                <option value="Decorative Mirror">Decorative Mirror</option>
                                <option value="Other">Other Requirement</option>
                            </select>
                        </div>
                    </div>

                    <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest pl-1">Tell us about your project</label>
                        <Textarea 
                            placeholder="Please provide site location and specific details..." 
                            value={formData.message}
                            onChange={(e) => setFormData({...formData, message: e.target.value})}
                            className="min-h-[140px] rounded-xl border-2 border-slate-50 focus:border-sky-500 font-bold p-4"
                        />
                    </div>

                    <Button 
                        type="submit" 
                        disabled={submitting}
                        className="w-full h-16 rounded-xl font-bold uppercase tracking-widest text-base gap-3 shadow-xl transition-all hover:scale-[1.02] active:scale-95" 
                        style={{ backgroundColor: BLUE }}
                    >
                        {submitting ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
                        {submitting ? "Sending..." : "Request Call-Back"}
                    </Button>
                </form>

                <div className="mt-8 flex items-center justify-center gap-6 text-muted-foreground/40">
                    <div className="flex items-center gap-2">
                        <ShieldCheck className="w-4 h-4" />
                        <span className="text-[10px] font-bold uppercase tracking-wider">Secure Connection</span>
                    </div>
                    <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4" />
                        <span className="text-[10px] font-bold uppercase tracking-wider">Fast Response</span>
                    </div>
                </div>
            </div>
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section className="w-full h-[500px] mt-12 overflow-hidden border-t border-border">
          <iframe 
            src={data.mapEmbedUrl}
            width="100%" 
            height="100%" 
            style={{ border: 0, filter: 'grayscale(0.1) contrast(1.1)' }} 
            allowFullScreen={true} 
            loading="lazy" 
            referrerPolicy="no-referrer-when-downgrade"
            title="Office Location"
          />
      </section>
    </div>
  );
};

export default Contact;
