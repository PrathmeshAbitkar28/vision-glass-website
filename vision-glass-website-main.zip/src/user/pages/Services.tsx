import { useQuery } from "@tanstack/react-query";
import PageHero from "@/user/components/PageHero";
import { ArrowRight, Loader2, ShieldCheck, CheckCircle } from "lucide-react";
import { Link } from "react-router-dom";
import { getCollectionContent } from "@/shared/lib/firestore-service";
import EnquiryCTA from "@/user/components/EnquiryCTA";
import { optimizeUrl, Breakpoints } from "@/shared/lib/image-optimizer";

const BLUE = "#0ea5e9";

const DEFAULT_SERVICES = [
    {
        title: "Glass Partitions",
        subtitle: "Office & Commercial",
        desc: "Full and partial glass partition walls for offices, cabins and conference rooms.",
        image: "https://images.unsplash.com/photo-1497366811353-6870744d04b2?w=700&q=85",
        tags: ["Frameless", "Framed", "Office Cabins"]
    },
    {
        title: "Aluminium & UPVC Windows",
        subtitle: "Windows & Partitions",
        desc: "Durable, weather-resistant window frames and partition systems.",
        image: "https://images.unsplash.com/photo-1509644851169-2acc08aa25b5?w=700&q=85",
        tags: ["Aluminium", "UPVC", "Casement"]
    }
];

const Services = () => {
  const { data: servicesList = DEFAULT_SERVICES, isLoading: loading } = useQuery({
    queryKey: ["services-list"],
    queryFn: async () => {
      const data = await getCollectionContent("services");
      return data.length > 0 ? data : DEFAULT_SERVICES;
    },
    staleTime: 1000 * 60 * 15, // 15 minutes
  });

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
    </div>
  );

  return (
    <div className="animate-in fade-in duration-700">
      <PageHero
        title="Our Services"
        subtitle="Industrial glass and window systems for modern architecture"
        breadcrumb={[{ label: "Home", to: "/" }, { label: "Services" }]}
      />

      {/* Page Content */}
      <section className="py-20 md:py-32 bg-background">
        <div className="w-full px-5 md:px-12 lg:px-24">
          <div className="text-center mb-20 max-w-3xl mx-auto">
            <div className="flex items-center justify-center gap-3 mb-4">
              <div className="w-10 h-[2px] rounded-full bg-primary" />
              <p className="text-primary text-xs font-semibold uppercase tracking-widest">Our Expertise</p>
              <div className="w-10 h-[2px] rounded-full bg-primary" />
            </div>
            <h2 className="text-3xl md:text-5xl font-extrabold tracking-tight text-black mb-6 uppercase leading-tight">Expert Solutions</h2>
            <p className="text-muted-foreground text-base md:text-lg leading-relaxed font-bold">
               Professional finishing has earned the trust of leading architects, builders, and schools.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {servicesList.map((s, i) => (
              <div
                key={i}
                className="group rounded-2xl overflow-hidden border border-border bg-card hover:bg-white hover:shadow-2xl hover:border-transparent transition-all duration-300"
              >
                <div className="relative h-64 overflow-hidden">
                  <img
                    src={optimizeUrl(s.image, 600)}
                    alt={s.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-60 group-hover:opacity-90 transition-opacity" />
                  <div className="absolute bottom-6 left-6">
                    <span className="bg-sky-500 text-[10px] font-black uppercase text-white px-3 py-1 rounded-full tracking-widest">
                      {s.subtitle || "Service Line"}
                    </span>
                  </div>
                </div>
                <div className="p-8">
                  <h3 className="font-bold text-2xl text-black leading-tight mb-4 uppercase tracking-tight">{s.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed mb-8 font-bold line-clamp-3">{s.desc}</p>
                  
                  <div className="flex flex-wrap gap-2 mb-8">
                     {s.tags?.map((tag: string) => (
                       <span key={tag} className="flex items-center gap-1.5 text-[10px] font-bold text-muted-foreground bg-muted px-2.5 py-1.5 rounded-md uppercase tracking-widest">
                          <CheckCircle className="w-3 h-3 text-sky-500" /> {tag}
                       </span>
                     ))}
                  </div>

                  <div className="pt-6 border-t border-border flex items-center justify-between">
                      <Link
                        to="/contact"
                        className="inline-flex items-center gap-2 text-sm font-semibold transition-all duration-300 group-hover:translate-x-1"
                        style={{ color: BLUE }}
                      >
                        Enquire Now <ArrowRight className="w-4 h-4" />
                      </Link>
                      <div className="flex items-center gap-2 text-muted-foreground/60 transition-colors group-hover:text-sky-500">
                         <ShieldCheck className="w-5 h-5" />
                         <span className="text-[9px] font-bold uppercase tracking-widest">Certified</span>
                      </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <EnquiryCTA />
    </div>
  );
};

export default Services;
