import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import PageHero from "@/user/components/PageHero";
import { Badge } from "@/shared/components/ui/badge";
import { 
  X, 
  Maximize, 
  Loader2, 
  Camera, 
  Sparkles
} from "lucide-react";
import { getCollectionContent } from "@/shared/lib/firestore-service";
import EnquiryCTA from "@/user/components/EnquiryCTA";
import { optimizeUrl, Breakpoints } from "@/shared/lib/image-optimizer";

interface GalleryItem {
  id?: string;
  title: string;
  category: string;
  image: string;
}

const Gallery = () => {
  const [filter, setFilter] = useState("All");
  const [selectedImage, setSelectedImage] = useState<GalleryItem | null>(null);

  const { data: galleryItems = [], isLoading: loading } = useQuery<GalleryItem[]>({
    queryKey: ["gallery-items"],
    queryFn: async () => {
      const data = await getCollectionContent("gallery");
      const sorted = (data as GalleryItem[]).sort((a, b) => (b.title || "").localeCompare(a.title || ""));
      if (sorted.length > 0) return sorted;
      return [
        { title: "Glass Facade", category: "Commercial", image: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800&q=80" },
        { title: "Structural Window", category: "Residential", image: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800&q=80" },
        { title: "Industrial Vision", category: "Industrial", image: "https://images.unsplash.com/photo-1503387762-592deb58ef4e?w=800&q=80" }
      ];
    },
    staleTime: 1000 * 60 * 15, // 15 minutes
  });

  const categories = ["All", ...Array.from(new Set(galleryItems.map(item => item.category)))];
  
  const filteredItems = filter === "All" 
    ? galleryItems 
    : galleryItems.filter(item => item.category === filter);

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
    </div>
  );

  return (
    <div className="animate-in fade-in duration-700 min-h-screen bg-background">
      <PageHero
        title="Our Gallery"
        subtitle="Exploring the art of architectural glass"
        breadcrumb={[{ label: "Home", to: "/" }, { label: "Gallery" }]}
      />

      {/* ── Filter Bar ── */}
      <div className="w-full px-5 md:px-16 lg:px-24 -mt-8 md:-mt-10 relative z-20">
        <div className="bg-white border border-border rounded-[1.5rem] md:rounded-2xl p-3 md:p-6 shadow-xl flex flex-wrap items-center justify-center gap-2 md:gap-3">
           {categories.map((cat: string) => (
             <button
               key={cat}
               onClick={() => setFilter(cat)}
               className={`px-5 md:px-8 py-2.5 md:py-3 rounded-[0.8rem] md:rounded-xl text-[10px] md:text-sm font-bold uppercase tracking-wider transition-all duration-300 scale-100 hover:scale-[1.03] active:scale-[0.98] ${
                 filter === cat 
                   ? "bg-primary text-white shadow-lg shadow-primary/30" 
                   : "bg-muted text-muted-foreground hover:bg-muted/80"
               }`}
             >
               {cat}
             </button>
           ))}
        </div>
      </div>

      <section className="w-full px-5 md:px-16 lg:px-24 pt-16 md:pt-20 pb-20">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredItems.map((item, i) => (
            <div
              key={i}
              className="group relative h-[420px] rounded-2xl overflow-hidden bg-card border border-border shadow-md hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 cursor-pointer"
              onClick={() => setSelectedImage(item)}
            >
              <img
                src={optimizeUrl(item.image, Breakpoints.Card)}
                alt={item.title}
                className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110"
                loading="lazy"
              />
              
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              
              <div className="absolute top-6 right-6 scale-0 group-hover:scale-100 transition-transform duration-400">
                <div className="w-12 h-12 rounded-xl bg-primary shadow-2xl flex items-center justify-center text-white">
                   <Maximize className="w-6 h-6" />
                </div>
              </div>

              <div className="absolute top-6 left-6 opacity-0 group-hover:opacity-100 transition-opacity delay-100">
                  <Badge className="bg-sky-500 text-white font-black uppercase text-[10px] px-3 py-1 rounded-full border-0 shadow-lg">
                     {item.category}
                  </Badge>
              </div>

              <div className="absolute bottom-6 left-6 right-6 translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500 delay-200">
                <h3 className="text-xl font-bold text-white uppercase tracking-tight leading-none mb-2">
                  {item.title}
                </h3>
              </div>
            </div>
          ))}
        </div>
        
        {!filteredItems.length && (
           <div className="py-40 text-center opacity-10">
              <Camera className="w-24 h-24 mx-auto mb-8" />
              <h3 className="text-xl font-bold uppercase tracking-widest italic leading-none">Media Synchronizing...</h3>
           </div>
        )}
      </section>

      <EnquiryCTA />

      {/* ── Lightbox ── */}
      {selectedImage && (
        <div 
          className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-10 overflow-hidden"
          onClick={() => setSelectedImage(null)}
        >
          <div className="absolute inset-0 bg-black/95 backdrop-blur-md animate-in fade-in duration-500" />
          
          <button className="absolute top-6 right-6 w-14 h-14 flex items-center justify-center text-white/40 hover:text-white rounded-full bg-white/5 hover:bg-white/10 transition-colors z-[110]">
             <X className="w-8 h-8" />
          </button>

          <div 
            className="relative w-full h-full max-w-5xl animate-in zoom-in-95 duration-500 flex flex-col gap-6"
            onClick={(e) => e.stopPropagation()}
          >
             <div className="relative flex-1 rounded-2xl overflow-hidden shadow-3xl border border-white/5">
                <img 
                  src={optimizeUrl(selectedImage.image, Breakpoints.Section)} 
                  className="w-full h-full object-contain" 
                  alt="" 
                />
             </div>
              <div className="flex flex-col sm:flex-row items-center sm:justify-between pb-6 border-b border-white/5 text-center sm:text-left gap-4">
                <div>
                   <h2 className="text-xl md:text-3xl font-extrabold text-white uppercase tracking-tight leading-none mb-3">
                      {selectedImage.title}
                   </h2>
                   <Badge className="bg-sky-500 text-black font-black uppercase tracking-widest px-4 h-8 rounded-full border-0 text-[10px]">
                      {selectedImage.category} Reference
                   </Badge>
                </div>
                <div className="hidden sm:flex items-center gap-2 text-sky-400 opacity-40">
                    <Sparkles className="w-5 h-5" />
                    <span className="text-[10px] font-bold uppercase tracking-[0.2em]">Signature Project</span>
                </div>
              </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Gallery;
