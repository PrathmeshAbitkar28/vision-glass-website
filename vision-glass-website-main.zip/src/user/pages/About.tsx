import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import PageHero from "@/user/components/PageHero";
import {
  CheckCircle, Users, Award, Wrench, Building2,
  HardHat, Stethoscope, GraduationCap, Factory,
  PenTool, Hammer, ShoppingBag,
  LucideIcon, Loader2
} from "lucide-react";
import { getSiteMetadata } from "@/shared/lib/firestore-service";
import EnquiryCTA from "@/user/components/EnquiryCTA";
import { optimizeUrl, Breakpoints } from "@/shared/lib/image-optimizer";

const DEFAULT_ABOUT_DATA = {
    yearsExperience: "15+",
    leaderName: "Pratap Bhagwanrao Kathare",
    introTitle: "Vision Glass Creation",
    introText1: "Vision Glass Creation is Pune's trusted expert in premium window and glass solutions.",
    introText2: "Professional finishing has earned the trust of leading architects, builders, hospitals, and schools.",
    whyChoose: [
        { title: "One-Stop Solution", desc: "Complete window and glass work under one roof." },
        { title: "Quality Workmanship", desc: "Professional finishing and attention to detail." },
        { title: "Trusted by Leaders", desc: "Architects, hospitals, and builders rely on us." },
        { title: "End-to-End Service", desc: "From consultation to final installation." }
    ],
    clientTabs: [
        { label: "Architects", clients: ["Arct Uday Kulkarni", "Arct Ashish Shinde"] },
        { label: "Builders", clients: ["Garve Developers", "VT Adaskar"] },
        { label: "Industrial", clients: ["SGS Chakan Mumbai", "Bajaj Auto"] }
    ],
    industries: [{ title: "Architects" }, { title: "Facility Management" }],
    projectCount: "500+ Projects",
    directLiaison: "Direct Liaison"
};

const iconMap: Record<string, LucideIcon> = {
  "Architects": PenTool,
  "Interior Designers": Hammer,
  "Builders": HardHat,
  "Hospitals": Stethoscope,
  "Schools": GraduationCap,
  "Industrial": Factory,
  "One-Stop Solution": Building2,
  "Quality Workmanship": Award,
  "Trusted by Leaders": Users,
  "End-to-End Service": Wrench,
  "Facility Management": Building2,
  "Interior Decorators": Hammer,
  "Carpenters": Wrench,
  "Builders & Developers": HardHat,
  "MEP Contractors": Wrench,
  "Industrial Decorators": Factory,
  "Real Estate Developers": HardHat,
  "HR & Purchase Depts.": ShoppingBag,
};

const getIcon = (label: string) => iconMap[label] || Building2;

const About = () => {
  const [activeTab, setActiveTab] = useState(0);

  const { data: aboutData = DEFAULT_ABOUT_DATA, isLoading: loading } = useQuery({
    queryKey: ["about-metadata"],
    queryFn: async () => {
      const result = await getSiteMetadata("about");
      return result ? result : DEFAULT_ABOUT_DATA;
    },
    staleTime: 1000 * 60 * 30, // 30 minutes
  });

  const data = aboutData;

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
    </div>
  );

  return (
    <div className="animate-in fade-in duration-700">
      <PageHero
        title="About Us"
        subtitle="Building trust through glass, one project at a time"
        breadcrumb={[{ label: "Home", to: "/" }, { label: "About" }]}
      />

      {/* ── 1. COMPANY INTRO ── */}
      <section className="py-20 md:py-32 bg-background">
        <div className="w-full px-5 md:px-12 lg:px-24">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="relative">
              <img
                src={optimizeUrl("https://images.unsplash.com/photo-1486325212027-8081e485255e", Breakpoints.Card)}
                alt="Vision Glass"
                className="rounded-2xl shadow-xl w-full h-[500px] object-cover"
              />
              <div className="absolute -bottom-8 -right-8 bg-white border border-border rounded-2xl p-8 shadow-2xl hidden md:block">
                <p className="text-5xl font-extrabold text-primary mb-1 tracking-tight">{data.yearsExperience}</p>
                <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Years of excellence</p>
              </div>
            </div>

            <div className="space-y-8">
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-[2px] rounded-full bg-primary" />
                  <p className="text-primary text-xs font-semibold uppercase tracking-widest">Our Story</p>
                </div>
                <h2 className="text-4xl md:text-5xl font-extrabold tracking-tight text-black mb-6">
                  {data.introTitle}
                </h2>
                <div className="text-primary text-sm font-bold uppercase tracking-widest mb-6">Led by {data.leaderName}</div>
                <p className="text-lg text-black font-semibold leading-relaxed mb-6">
                  {data.introText1}
                </p>
                <p className="text-muted-foreground leading-relaxed">
                  {data.introText2}
                </p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-full bg-sky-50 flex items-center justify-center shrink-0">
                          <CheckCircle className="w-5 h-5 text-sky-500" />
                      </div>
                      <span className="font-bold text-black uppercase text-xs tracking-wider">{data.projectCount || "500+ Projects"}</span>
                  </div>
                  <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-full bg-sky-50 flex items-center justify-center shrink-0">
                          <CheckCircle className="w-5 h-5 text-sky-500" />
                      </div>
                      <span className="font-bold text-black uppercase text-xs tracking-wider">{data.directLiaison || "Direct Liaison"}</span>
                  </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── 2. WHY CHOOSE US ── */}
      <section className="relative py-28 overflow-hidden">
        <img
          src={optimizeUrl("https://images.unsplash.com/photo-1545324418-cc1a3fa10c00", Breakpoints.Hero)}
          alt="Modern Architecture"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0" style={{ background: "linear-gradient(135deg, rgba(2,6,23,0.95) 0%, rgba(14,165,233,0.85) 100%)" }} />

        <div className="relative z-10 container mx-auto px-4 text-white">
            <div className="mb-16 text-center">
                <p className="text-sky-300 text-xs font-semibold uppercase tracking-[0.25em] mb-4">Why Choose Us</p>
                <h2 className="text-3xl md:text-5xl font-extrabold tracking-tight">The Vision Edge</h2>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {data.whyChoose?.map((item: any, i: number) => {
                    const Icon = getIcon(item.title);
                    return (
                        <div key={i} className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-8 hover:bg-white/10 transition-all duration-300">
                            <div className="w-12 h-12 rounded-xl bg-sky-400 flex items-center justify-center mb-6">
                                <Icon className="w-6 h-6 text-black" />
                            </div>
                            <h3 className="text-xl font-bold mb-3 uppercase tracking-tight">{item.title}</h3>
                            <p className="text-white/60 text-sm leading-relaxed">{item.desc}</p>
                        </div>
                    );
                })}
            </div>
        </div>
      </section>

      {/* ── 3. CLIENT PORTFOLIO ── */}
      <section className="py-24 md:py-32 bg-[#f8fafc]">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center mb-16">
            <div className="flex items-center justify-center gap-3 mb-4">
              <div className="w-10 h-[2px] rounded-full bg-primary" />
              <p className="text-primary text-xs font-semibold uppercase tracking-widest">Client Network</p>
              <div className="w-10 h-[2px] rounded-full bg-primary" />
            </div>
            <h2 className="text-4xl md:text-5xl font-extrabold tracking-tight text-slate-900 mb-6">Proven Track Record</h2>
            <p className="text-slate-500 text-lg">
                Trusted by the industry's most demanding professionals and organizations across Pune's architectural landscape.
            </p>
          </div>

          <div className="max-w-5xl mx-auto">
              <div className="flex flex-wrap justify-center gap-3 mb-12">
                {data.clientTabs?.map((tab: any, i: number) => (
                  <button
                    key={i}
                    onClick={() => setActiveTab(i)}
                    className={`px-8 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all duration-300 border-2 ${
                        activeTab === i 
                        ? "bg-slate-900 text-white border-slate-900 shadow-xl" 
                        : "bg-white text-slate-400 border-slate-100 hover:border-slate-300 hover:text-slate-600"
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>

              <div className="bg-white rounded-[2rem] border border-slate-200 p-8 md:p-16 shadow-2xl relative overflow-hidden group">
                <div className="absolute top-0 left-0 w-full h-1.5 bg-sky-500" />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-6">
                  {data.clientTabs?.[activeTab]?.clients?.map((client: string, i: number) => (
                    <div key={i} className="flex items-center gap-5 py-4 border-b border-slate-50 last:border-0 hover:bg-slate-50/50 transition-colors px-4 rounded-lg">
                      <div className="w-8 h-8 rounded-full bg-sky-50 flex items-center justify-center shrink-0 border border-sky-100">
                        <CheckCircle className="w-4 h-4 text-sky-500" />
                      </div>
                      <span className="font-bold text-slate-800 uppercase text-sm tracking-tight">{client}</span>
                    </div>
                  ))}
                </div>
                
                {data.clientTabs?.[activeTab]?.clients?.length === 0 && (
                   <div className="text-center py-10">
                      <p className="text-slate-400 italic">No entries synchronized for this sector yet.</p>
                   </div>
                )}
              </div>
          </div>
        </div>
      </section>

      {/* ── 4. SECTOR SPECIALIZATION (WHO WE WORK WITH) ── */}
      <section className="py-20 md:py-32 bg-white border-t border-slate-100">
        <div className="w-full px-5 md:px-12 lg:px-24">
            <div className="flex flex-col items-center mb-20 space-y-4">
                <div className="flex items-center gap-4">
                    <div className="h-[2px] w-12 bg-sky-500" />
                    <span className="text-sky-600 text-[10px] font-black uppercase tracking-[0.4em] italic">Sector Domain</span>
                    <div className="h-[2px] w-12 bg-sky-500" />
                </div>
                <h2 className="text-4xl md:text-6xl font-black tracking-tighter text-[#020617] text-center uppercase leading-none">
                    WHO WE WORK WITH
                </h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6 lg:gap-10">
                {data.industries?.map((item: any, i: number) => {
                    const Icon = getIcon(item.title);
                    return (
                        <div key={i} className="group relative flex flex-col items-center justify-center p-12 bg-[#0ea5e9] border border-white/10 rounded-[3rem] hover:bg-[#020117] transition-all duration-700 hover:scale-105 hover:shadow-[0_20px_60px_rgba(14,165,233,0.35)] shadow-xl">
                            {/* Structural Accent Reveal */}
                            <div className="absolute top-0 left-0 w-full h-1 bg-white/20 opacity-0 group-hover:opacity-100 transition-opacity" />
                            
                            <div className="w-24 h-24 rounded-full bg-white/15 flex items-center justify-center text-white mb-10 group-hover:bg-sky-500 group-hover:scale-110 transition-all duration-500 shadow-inner">
                                <Icon className="w-12 h-12" />
                            </div>
                            
                            <span className="text-[11px] font-black uppercase tracking-[0.2em] text-center leading-tight text-white group-hover:text-sky-400 transition-colors duration-500">
                                {item.title}
                            </span>
                        </div>
                    );
                })}
            </div>

            <div className="mt-20 pt-10 border-t border-slate-50 flex justify-center">
                <p className="text-slate-400 text-[10px] font-bold uppercase tracking-[0.3em] max-w-4xl text-center leading-relaxed italic">
                    Delivering precision-engineered structural glass solutions across commercial, institutional, and residential sectors in Pune.
                </p>
            </div>
        </div>
      </section>

      <EnquiryCTA />
    </div>
  );
};

export default About;
