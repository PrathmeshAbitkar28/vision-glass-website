import { Link } from "react-router-dom";
import { useEffect, useRef, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/shared/components/ui/button";
import {
  ArrowRight,
  PanelTop,
  Frame,
  Building2,
  Layers,
  Paintbrush,
  Lamp,
  Shield,
  CheckCircle,
  Loader2,
} from "lucide-react";

import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { getSiteMetadata } from "@/shared/lib/firestore-service";
import EnquiryCTA from "@/user/components/EnquiryCTA";
import Hero from "@/user/components/Hero";
import { optimizeUrl, Breakpoints } from "@/shared/lib/image-optimizer";

gsap.registerPlugin(ScrollTrigger);

const BLUE = "#0ea5e9";

const ICON_MAP: Record<string, any> = {
  "PanelTop": PanelTop,
  "Frame": Frame,
  "Building2": Building2,
  "Layers": Layers,
  "Lamp": Lamp,
  "Paintbrush": Paintbrush,
  "Shield": Shield
};

const DEFAULT_HOME_DATA = {
    heroTitle1: "Expert in Window",
    heroTitle2: "& Glass Solutions",
    heroSubtitle: "Premium glass partitions, facades, mirrors and window solutions for commercial, residential and industrial spaces across Pune.",
    heroImage: "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=1920&q=90",
    heroImages: [
        "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=1920&q=90",
        "https://images.unsplash.com/photo-1486325212027-8081e485255e?w=1920&q=90",
        "https://images.unsplash.com/photo-1509391366360-2e959784a276?w=1920&q=90"
    ],
    
    servicesTitle: "Our Services",
    servicesSubtitle: "End-to-end glass solutions, crafted with precision and delivered with care across Pune's skyline.",
    services: [
        { title: "Glass Partitions", desc: "Frameless and framed partition walls for modern offices and commercial cabins.", image: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=800&q=85", icon: "PanelTop" },
        { title: "Aluminium & UPVC Windows", desc: "Weather-sealed, thermally efficient window systems for every building type.", image: "https://images.unsplash.com/photo-1509391366360-2e959784a276?w=800&q=85", icon: "Frame" },
        { title: "Structural Facade", desc: "High-performance curtain wall and structural glazing for commercial towers.", image: "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=1920&q=90", icon: "Building2" },
        { title: "Glass Glazing", desc: "Toughened safety glass and composite ACP panel installations inside and out.", image: "https://images.unsplash.com/photo-1486325212027-8081e485255e?w=800&q=85", icon: "Layers" },
        { title: "Interior Glass Solutions", desc: "Custom glass shelving, display units, and complete interior glass fitouts.", image: "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&q=85", icon: "Lamp" },
        { title: "Decorative & LED Mirrors", desc: "Backlit LED mirrors, vastu mirrors, and bespoke decorative installations.", image: "https://images.unsplash.com/photo-1618220179428-22790b461013?w=800&q=85", icon: "Paintbrush" },
    ],

    trustTitle: "Trusted by Industry Leaders",
    trustSubtitle: "From architects to industrialists — they all rely on Vision Glass.",
    trustedBy: [
        { label: "Architects", desc: "Leading firms across Pune", image: "https://images.unsplash.com/photo-1503387762-592deb58ef4e?w=600&q=80" },
        { label: "Builders", desc: "Residential & commercial developers", image: "https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=600&q=80" },
        { label: "Hospitals", desc: "Healthcare facilities & clinics", image: "https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=600&q=80" },
        { label: "Schools", desc: "Educational institutions", image: "https://images.unsplash.com/photo-1580582932707-520aed937b7b?w=600&q=80" },
        { label: "Industrial", desc: "Factories & manufacturing units", image: "https://images.unsplash.com/photo-1565043666747-69f6646db940?w=600&q=80" },
    ],

    uspBackgroundImage: "https://images.unsplash.com/photo-1486325212027-8081e485255e?w=1800&q=85",
    uspTitle: "Complete glass solutions under one roof — quality guaranteed.",
    uspSubtitle: "Professional finishing on every project, large or small.",
    uspPoints: [
        "One-stop glass solution provider",
        "Professional installation team",
        "Trusted by 50+ architects & builders",
        "Quality workmanship guaranteed",
    ],

    referTitle: "Know Someone Who Needs Us?",
    referSubtitle: "Help them connect with the right glass solution.",
    referCards: [
        { question: "Looking for office cabin or glass partition work?", sub: "We design and install custom office partitions across Pune.", icon: "PanelTop" },
        { question: "Need to replace broken cabin or window glass?", sub: "Fast, reliable glass replacement with professional finishing.", icon: "Frame" },
        { question: "Searching for soundproof glass or window solutions?", sub: "Acoustic glass systems engineered for peace and privacy.", icon: "Shield" },
    ],
    enquiryCTATitle: "Ready to Start Your Project?",
    enquiryCTASubtitle: "Get a free consultation and quote for your glass requirements today.",
    enquiryCTAItems: [
        "Expert Consultation",
        "Transparent Pricing",
        "Quality Workmanship",
        "On-Time Delivery"
    ]
};

const Index = () => {
  const mainRef = useRef<HTMLDivElement>(null);

  const { data: homeData, isLoading: loading } = useQuery({
    queryKey: ["home-metadata"],
    queryFn: async () => {
      const result = await getSiteMetadata("home");
      return result ? { ...DEFAULT_HOME_DATA, ...result } : DEFAULT_HOME_DATA;
    },
    staleTime: 1000 * 60 * 10, // 10 minutes
  });

  const data = homeData || DEFAULT_HOME_DATA;

  useEffect(() => {
    if (loading || !data) return;

    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: "power3.out" }, delay: 0.3 });
      tl.from(".hero-badge", { y: 20, opacity: 0, scale: 0.92, duration: 0.8 })
        .from(".hero-line", { y: 60, opacity: 0, filter: "blur(8px)", duration: 1.1, stagger: 0.18 }, "-=0.3")
        .from(".hero-sub", { y: 28, opacity: 0, duration: 0.9 }, "-=0.5")
        .from(".hero-btns > *", { y: 20, opacity: 0, duration: 0.7, stagger: 0.12 }, "-=0.5")
        .from(".hero-scroll", { y: 10, opacity: 0, duration: 0.6 }, "-=0.3");

      gsap.to(".float-a", { y: -22, rotation: 2, duration: 4, ease: "sine.inOut", yoyo: true, repeat: -1 });
      gsap.to(".float-b", { y: -15, rotation: -2, duration: 5.5, ease: "sine.inOut", yoyo: true, repeat: -1 });
      gsap.to(".float-c", { y: -18, rotation: 1.5, duration: 4.8, ease: "sine.inOut", yoyo: true, repeat: -1 });

      gsap.utils.toArray<HTMLElement>(".gsap-section").forEach((section) => {
        const headings = section.querySelectorAll(".gsap-heading");
        const cards = section.querySelectorAll(".gsap-card");
        const stl = gsap.timeline({ scrollTrigger: { trigger: section, start: "top 82%" } });
        if (headings.length) stl.from(headings, { y: 32, opacity: 0, duration: 0.85, stagger: 0.12, ease: "power3.out" });
        if (cards.length) stl.from(cards, { y: 50, opacity: 0, duration: 0.8, stagger: 0.1, ease: "power3.out" }, "-=0.4");
      });
    }, mainRef);
    return () => ctx.revert();
  }, [loading, data]);

  if (loading) return (
      <div className="min-h-screen flex items-center justify-center bg-black">
          <Loader2 className="w-10 h-10 animate-spin text-sky-500" />
      </div>
  );

  return (
    <div ref={mainRef}>
      <Hero data={data} />


      {/* ════════════ SERVICES ════════════ */}
      <section className="gsap-section py-20 md:py-32 bg-background">
        <div className="w-full px-5 md:px-12 lg:px-24">
          <div className="text-center mb-12 md:mb-20">
            <div className="gsap-heading flex items-center justify-center gap-3 mb-4">
              <div className="w-10 h-[2px] rounded-full bg-primary" />
              <p className="text-primary text-[10px] md:text-xs font-semibold uppercase tracking-[0.22em]">What We Do</p>
              <div className="w-10 h-[2px] rounded-full bg-primary" />
            </div>
            <h2 className="gsap-heading text-3xl sm:text-4xl md:text-6xl font-black tracking-tighter text-black mb-4 uppercase leading-[1.1]">{data.servicesTitle}</h2>
            <p className="gsap-heading text-black text-base md:text-xl max-w-2xl mx-auto leading-relaxed font-bold">
              {data.servicesSubtitle}
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {data.services?.map((s: any) => (
              <Link key={s.title} to="/services" className="gsap-card service-card-outer group relative">
                <div className="service-card-inner relative rounded-2xl overflow-hidden bg-card border border-border group-hover:border-transparent group-hover:shadow-2xl">
                  <div className="relative h-56 overflow-hidden">
                    <img src={optimizeUrl(s.image, 600)} alt={s.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out" loading="lazy" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="text-white text-lg font-bold leading-tight drop-shadow-md">{s.title}</h3>
                    </div>
                  </div>
                  <div className="p-6">
                    <p className="text-black text-sm leading-relaxed mb-4 font-bold">{s.desc}</p>
                    <span className="inline-flex items-center gap-2 text-sm font-semibold" style={{ color: BLUE }}>
                      Learn More <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
                    </span>
                  </div>
                  <div className="absolute bottom-0 left-0 h-[3px] w-0 group-hover:w-full transition-all duration-500" style={{ backgroundColor: BLUE }} />
                </div>
              </Link>
            ))}
          </div>

          <div className="gsap-heading text-center mt-12">
            <Link to="/services">
              <Button size="lg" className="rounded-full px-12 h-14 font-bold transition-all duration-300 shadow-xl shadow-sky-400/20 hover:scale-[1.02] hover:shadow-2xl"
                style={{ backgroundColor: BLUE, color: "#fff", borderColor: BLUE }}
              >
                View All Services <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>


      {/* ════════════ USP BANNER ════════════ */}
      <section className="gsap-section relative py-28 overflow-hidden">
        <img src={optimizeUrl(data.uspBackgroundImage, 1600)} alt="Glass building facade" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0" style={{ background: "linear-gradient(135deg,rgba(2,6,23,0.94) 0%,rgba(14,165,233,0.82) 100%)" }} />
        <div className="relative z-10 w-full px-6 md:px-12 lg:px-20 text-center text-white">
          <p className="gsap-heading text-sky-300 text-xs font-semibold uppercase tracking-[0.25em] mb-5">Our Promise</p>
          <h2 className="gsap-heading text-3xl md:text-5xl font-extrabold tracking-[-0.02em] mb-6 max-w-3xl mx-auto leading-tight">
            {data.uspTitle}
          </h2>
          <p className="gsap-heading text-white/60 text-lg mb-10 font-light">{data.uspSubtitle}</p>
          <div className="gsap-card grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-12 text-left w-full max-w-7xl mx-auto">
            {data.uspPoints?.map((pt: string) => (
              <div key={pt} className="flex items-center gap-4 bg-white/10 md:bg-white/5 backdrop-blur-md border border-white/20 md:border-white/10 rounded-2xl p-5 hover:bg-white/15 transition-all duration-300">
                <CheckCircle className="w-5 h-5 sm:w-6 sm:h-6 text-sky-400 shrink-0" />
                <span className="text-sm sm:text-base font-bold tracking-wide uppercase">{pt}</span>
              </div>
            ))}
          </div>
          <Link to="/contact">
            <Button size="lg" className="rounded-full px-10 text-base font-semibold bg-white text-foreground hover:bg-white/90 hover:scale-[1.02] transition-all duration-300 shadow-xl">
              Start Your Project
            </Button>
          </Link>
        </div>
      </section>


      {/* ════════════ TRUSTED BY ════════════ */}
      <section className="gsap-section py-24 md:py-28 bg-background overflow-hidden">
        <div className="w-full">
          <div className="text-center mb-14">
            <div className="gsap-heading flex items-center justify-center gap-3 mb-4">
              <div className="w-10 h-[2px] rounded-full bg-primary" />
              <p className="text-primary text-[10px] md:text-xs font-semibold uppercase tracking-[0.22em]">Who We Serve</p>
              <div className="w-10 h-[2px] rounded-full bg-primary" />
            </div>
            <h2 className="gsap-heading text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tighter text-black mb-3 px-4">
              {data.trustTitle}
            </h2>
            <p className="gsap-heading text-black text-base md:text-lg max-w-md mx-auto font-black px-4">
              {data.trustSubtitle}
            </p>
          </div>

          <div className="relative overflow-hidden w-full">
            <div
              className="flex gap-8 py-10"
              style={{
                width: "max-content",
                animation: "trustScroll 45s linear infinite",
              }}
              onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.animationPlayState = "paused"; }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.animationPlayState = "running"; }}
            >
              {[...(data.trustedBy || []), ...(data.trustedBy || []), ...(data.trustedBy || [])].map((item, i) => (
                <div key={`${item.label}-${i}`} className="gsap-card trusted-card-outer group shrink-0 w-[290px] sm:w-[350px] md:w-[380px]">
                  <div className="trusted-card-inner rounded-[2rem] sm:rounded-[2.5rem] overflow-hidden border-2 border-border bg-white shadow-2xl transition-all duration-500">
                    <div className="relative overflow-hidden h-[240px] sm:h-[300px]">
                      <img src={optimizeUrl(item.image, 500)} alt={item.label}
                        className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-110"
                        loading="lazy"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent" />
                      <p className="absolute bottom-6 left-0 right-0 text-center text-white font-black text-xl tracking-tight px-4 uppercase drop-shadow-lg">
                        {item.label}
                      </p>
                      <div className="absolute top-0 left-0 right-0 h-[5px]" style={{ backgroundColor: BLUE }} />
                    </div>
                    <div className="flex flex-col justify-center items-center px-6 sm:px-8 py-6 sm:py-8 text-center bg-white">
                      <p className="text-sm sm:text-lg text-black leading-relaxed font-medium">{item.desc}</p>
                      <div className="mt-4 sm:mt-5 h-[4px] sm:h-[5px] rounded-full w-0 group-hover:w-full transition-all duration-700" style={{ backgroundColor: BLUE }} />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <EnquiryCTA 
        title={data.enquiryCTATitle} 
        subtitle={data.enquiryCTASubtitle} 
        items={data.enquiryCTAItems}
      />


      {/* ════════════ REFER A CLIENT ════════════ */}
      <section className="gsap-section py-24 md:py-16 bg-background">
        <div className="w-full px-6 md:px-12 lg:px-20">
          <div className="text-center mb-12 md:mb-20">
            <div className="gsap-heading flex items-center justify-center gap-3 mb-4">
              <div className="w-10 h-[2px] rounded-full bg-primary" />
              <p className="text-primary text-[10px] md:text-[14px] font-black uppercase tracking-[0.25em]">Refer a Client</p>
              <div className="w-10 h-[2px] rounded-full bg-primary" />
            </div>
            <h2 className="gsap-heading text-3xl sm:text-4xl md:text-5xl font-black tracking-tighter text-black mb-4 uppercase">{data.referTitle}</h2>
            <p className="gsap-heading text-black text-base md:text-xl max-w-2xl mx-auto font-bold leading-relaxed px-4">{data.referSubtitle}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-7 items-stretch">
            {data.referCards?.map((card: any, i: number) => (
              <div key={i} className="gsap-card refer-card-outer group h-full">
                <div className="refer-card-inner h-full flex flex-col relative rounded-3xl border border-border bg-card p-8 text-center overflow-hidden group-hover:shadow-2xl group-hover:border-transparent">
                  <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
                    style={{ background: `radial-gradient(circle at 50% 0%,${BLUE}18 0%,transparent 70%)` }}
                  />
                  {/* Icon */}
                  <div className="relative w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6 transition-transform duration-300 group-hover:scale-110"
                    style={{ background: `${BLUE}18` }}
                  >
                    {(() => { const Icon = ICON_MAP[card.icon] || Shield; return <Icon className="w-7 h-7" style={{ color: BLUE }} />; })()}
                  </div>
                  {/* Title */}
                  <h3 className="text-xl font-black text-black mb-4 tracking-tight leading-snug uppercase">{card.question}</h3>
                  {/* Description — grows to push button down */}
                  <p className="text-black text-[16px] leading-relaxed font-bold flex-1 mb-8">{card.sub}</p>
                  {/* Button pinned to bottom */}
                  <Link to="/contact">
                    <Button
                      className="rounded-full w-full font-bold transition-all duration-300 shadow-lg shadow-sky-400/20 hover:scale-[1.02] hover:shadow-xl"
                      style={{ backgroundColor: BLUE, color: "#fff", borderColor: BLUE }}
                    >
                      Contact Us
                    </Button>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <style>{`
        @keyframes heroZoom {
          from { transform: scale(1.04); }
          to   { transform: scale(1.11); }
        }

        /* Service / Refer flicker fix */
        .service-card-outer, .refer-card-outer { padding-bottom: 6px; }
        .service-card-inner, .refer-card-inner {
          transition: transform 0.35s cubic-bezier(0.16,1,0.3,1), box-shadow 0.35s ease, border-color 0.25s ease;
          will-change: transform;
        }
        .service-card-outer:hover .service-card-inner,
        .refer-card-outer:hover   .refer-card-inner { transform: translateY(-6px); }

        /* refer-card-inner needs h-full respected through the outer shell */
        .refer-card-outer { display: flex; flex-direction: column; }
        .refer-card-inner { flex: 1; }

        /* Trusted by */
        .trusted-card-outer { padding-bottom: 6px; }
        .trusted-card-inner {
          transition: transform 0.35s cubic-bezier(0.16,1,0.3,1), box-shadow 0.35s ease, border-color 0.25s ease;
          will-change: transform;
        }
        .trusted-card-outer:hover .trusted-card-inner {
          transform: translateY(-8px);
          box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25);
          border-color: rgba(14,165,233,0.3);
        }
        @keyframes trustScroll {
          from { transform: translateX(0); }
          to   { transform: translateX(-50%); }
        }
      `}</style>
    </div>
  );
};

export default Index;
