import { useEffect, lazy, Suspense } from "react";
import { Toaster } from "@/shared/components/ui/toaster";
import { Toaster as Sonner } from "@/shared/components/ui/sonner";
import { TooltipProvider } from "@/shared/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Loader2 } from "lucide-react";
import Navbar from "@/user/components/Navbar";
import Footer from "@/user/components/Footer";
import FloatingButtons from "@/user/components/FloatingButtons";
import GlobalFont from "@/user/components/GlobalFont";
import ScrollToTop from "@/user/components/ScrollToTop";

// Lazy load user pages
const Index = lazy(() => import("@/user/pages/Index"));
const Services = lazy(() => import("@/user/pages/Services"));
const Gallery = lazy(() => import("@/user/pages/Gallery"));
const About = lazy(() => import("@/user/pages/About"));
const Contact = lazy(() => import("@/user/pages/Contact"));
const NotFound = lazy(() => import("@/user/pages/NotFound"));

// Lazy load admin pages
const AdminLayout = lazy(() => import("@/admin/pages/Layout"));
const Dashboard = lazy(() => import("@/admin/pages/Dashboard"));
const AdminAbout = lazy(() => import("@/admin/pages/About"));
const AdminContact = lazy(() => import("@/admin/pages/Contact"));
const AdminServices = lazy(() => import("@/admin/pages/ServicesManagement"));
const AdminGallery = lazy(() => import("@/admin/pages/GalleryManagement"));
const AdminInquiries = lazy(() => import("@/admin/pages/InquiryManagement"));
const HomeManagement = lazy(() => import("@/admin/pages/HomeManagement"));
const AdminLogin = lazy(() => import("@/admin/pages/Login"));
const ProtectedRoute = lazy(() => import("@/admin/components/ProtectedRoute"));

import { seedInitialData } from "@/shared/lib/firestore-service";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
      gcTime: 1000 * 60 * 30, // 30 minutes
    },
  },
});

const LoadingScreen = () => (
  <div className="min-h-screen flex items-center justify-center bg-black">
    <Loader2 className="w-10 h-10 animate-spin text-sky-500" />
  </div>
);

const UserLayout = ({ children }: { children: React.ReactNode }) => (
  <>
    <GlobalFont />
    <ScrollToTop />
    <Navbar />
    {children}
    <Footer />
    <FloatingButtons />
  </>
);

const App = () => {
  useEffect(() => {
    // Only seed if needed, check local storage to avoid redundant calls on every refresh
    const lastSeed = localStorage.getItem("last_seed_date");
    const today = new Date().toDateString();
    
    if (lastSeed !== today) {
      seedInitialData().then(() => {
        localStorage.setItem("last_seed_date", today);
      });
    }
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Suspense fallback={<LoadingScreen />}>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              {/* ── Public User Routes ── */}
              <Route path="/" element={<UserLayout><Index /></UserLayout>} />
              <Route path="/about" element={<UserLayout><About /></UserLayout>} />
              <Route path="/services" element={<UserLayout><Services /></UserLayout>} />
              <Route path="/gallery" element={<UserLayout><Gallery /></UserLayout>} />
              <Route path="/contact" element={<UserLayout><Contact /></UserLayout>} />

              {/* ── Admin Login (No Layout) ── */}
              <Route path="/admin/login" element={<AdminLogin />} />

              {/* ── Admin Dashboard (Protected & Layout) ── */}
              <Route 
                path="/admin" 
                element={
                  <ProtectedRoute>
                    <AdminLayout />
                  </ProtectedRoute>
                }
              >
                <Route index element={<HomeManagement />} />
                <Route path="home" element={<HomeManagement />} />
                <Route path="about" element={<AdminAbout />} />
                <Route path="contact" element={<AdminContact />} />
                <Route path="services" element={<AdminServices />} />
                <Route path="gallery" element={<AdminGallery />} />
                <Route path="inquiries" element={<AdminInquiries />} />
              </Route>

              {/* ── 404 Page ── */}
              <Route path="*" element={<UserLayout><NotFound /></UserLayout>} />
            </Routes>
          </BrowserRouter>
        </Suspense>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;
